from math import asin,sqrt,log,ceil,pi,sin
from random import random,choices
import pickle
from statistics import median


#--------------------Parameters-----------------------------------------------
TH = 1000000
num_repetitions = 100
reward_gap = 0.01
delta = 0.005
#choose the algorithm used
algo = "UCB"
#the cumulative regrets list (save the cumulative regret every 1000 rounds) will be saved in file 
file = r'./data/MAB_'+algo+'_'+str(delta)+"_"+str(reward_gap)+"_"+str(TH)+".txt"
#-----------------------------------------------------------------------------

class MAB_experiment:
    def __init__(self,num_arm,TH):
        self.num_arm = num_arm
        self.regret_UCB = [0]
        self.regret_QMAB = [0]
        self.rewards = [0.5-reward_gap*i for i in range(num_arm)]
        self.best = max(self.rewards)
        self.rewards_phase = [asin(sqrt(reward))/pi for reward in self.rewards]
        
    def bernoulli_rv(self,p):
        if random()<p:
            return 1
        else:
            return 0

    def D(self,x,y):
        m = (y-x)%1
        if m>0.5:
            return 1-m
        else:
            return m
        
    def pull_classical_arm(self,arm):
        self.regret_UCB.append(self.regret_UCB[-1]+self.best-self.rewards[arm])
        return self.bernoulli_rv(self.rewards[arm])
    
    def pull_quantum_arm(self,arm,bits,rep):
        f = True
        M = pow(2,bits)
        phase_estimation = [i/M for i in range(M)]
        weight = [0 for x in phase_estimation]
        for i,x in enumerate(phase_estimation):
            Up = (sin(M*self.D(self.rewards_phase[arm],x)*pi))**2
            Down = (M**2)*((sin(self.D(self.rewards_phase[arm],x)*pi))**2)
            if Down==0:
                estimation = self.rewards[arm]
                f = False
                break
            else:
                weight[i] = Up/Down
        if f:
            estimation = median([(sin(pi*x))**2 for x in choices(phase_estimation,weights = weight, k=rep)]) #Classically simulating the measurement result of QAE
        regret = self.best-self.rewards[arm]
        return estimation,regret,(M-1)*rep

    def UCB(self,delta,time_horizon):
        t = 1
        rewards = [0 for i in range(self.num_arm)]
        num_pull = [0 for i in range(self.num_arm)]
        ucb = [10 for i in range(self.num_arm)]
        while t<=time_horizon:
            arm_pull = ucb.index(max(ucb))
            reward = self.pull_classical_arm(arm_pull)
            rewards[arm_pull] += reward
            num_pull[arm_pull] += 1
            ucb[arm_pull] = rewards[arm_pull]/num_pull[arm_pull]+sqrt((2*log(1/delta))/num_pull[arm_pull])
            t += 1
        return True
    
    def QMAB(self,delta,time_horizon):
        rep = 5*ceil(log(1/delta))
        t = 0
        current_bit = [1 for i in range(self.num_arm)]
        ucb = [10 for i in range(self.num_arm)]
        while t < time_horizon:
            arm_pull = ucb.index(max(ucb))
            estimation,regret,num_queries = self.pull_quantum_arm(arm_pull, current_bit[arm_pull], rep)
            ucb[arm_pull] = estimation + pi*pow(1/2,current_bit[arm_pull])+pow(pi,2)*pow(1/4,current_bit[arm_pull])
            current_bit[arm_pull] += 1
            if t+num_queries<time_horizon:
                new_regret = [self.regret_QMAB[-1]+i*regret for i in range(1,num_queries+1)]
                self.regret_QMAB += new_regret
                t += num_queries
            else:
                new_regret = [self.regret_QMAB[-1]+i*regret for i in range(1,time_horizon-t+1)]
                self.regret_QMAB += new_regret
                t = time_horizon
        return True

data = []
for i in range(num_repetitions):
    print(i)
    experiment = MAB_experiment(2,TH)
    if algo == "UCB":
        experiment.UCB(delta,TH)
        data.append([experiment.regret_UCB[i] for i in range(0,TH+1,1000)])
    else:    
        experiment.QMAB(delta,TH)
        data.append([experiment.regret_QMAB[i] for i in range(0,TH+1,1000)])
    with open(file,'wb') as f:
        pickle.dump(data,f)
