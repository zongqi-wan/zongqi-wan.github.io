from math import asin,sqrt,log,ceil,pi,sin,cos
import numpy as np
from random import random,choices
import pickle
from statistics import median

#-------------------------Parameters------------------------------------------
TH = 100000
actions = 50
num_repetitions = 100
#choose the algorithm used
algo = 'QLinUCB'
delta =  2*log((TH*TH)/2+1)/TH
#the cumulative regrets list (save the cumulative regret every 1000 rounds) will be saved in file 
file = r'./data/SLB_'+algo+'_'+str(delta)+"_"+str(TH)+".txt"
#-----------------------------------------------------------------------------

class lin_bandit_experiment:
    def __init__(self,dimension,num_actions,time_horizon):
        self.dimension = dimension
        self.time_horizon = time_horizon
        self.regret_LinUCB = [0]
        self.regret_QLinUCB = [0]
        self.theta = np.matrix([cos(0.7*pi/2),sin(0.7*pi/2)])
        self.actions = np.matrix([[cos((i/num_actions)*pi/2),sin((i/num_actions)*pi/2)] for i in range(num_actions)])
        
        self.reward = [(self.actions[i]*self.theta.T)[0,0] for i in range(len(self.actions))]
        self.rewards_phase = [asin(sqrt(reward))/pi for reward in self.reward]
        self.best = max(self.reward)
        self.lamb = 1
        
    def offline_solver_finite(self,theta_hat,V_inv,stage,mode,XW=None,delta=None):
        if mode == "quantum":
            eig,_ = np.linalg.eig(XW.T*V_inv*XW)
            right = sqrt(stage*max(eig))+sqrt(self.lamb)
        else:
            #see Theorem 20.5, Bandit Algorithms, Tor Lattimore and Csaba Szepesv´ari
            right = sqrt(2*log(1/delta)-log(pow(self.lamb,self.dimension)*np.linalg.det(V_inv)))+sqrt(self.lamb)
        ucb = [(theta_hat.T*a.T)[0,0] + right*sqrt(a*V_inv*a.T) for a in self.actions]
        return ucb.index(max(ucb))
        
    def bernoulli_rv(self,p):
        if random()<p:
            return 1
        else:
            return 0

    def pull_classical_arm(self,a):
        self.regret_LinUCB.append(self.regret_LinUCB[-1]+self.best-(a*self.theta.T)[0,0])
        return self.bernoulli_rv((a*self.theta.T)[0,0])
    
    def D(self,x,y):
        m = (y-x)%1
        if m>0.5:
            return 1-m
        else:
            return m
        
    def pull_quantum_arm(self,arm,bits,rep):
        reward = (arm*self.theta.T)[0,0]
        phase = asin(sqrt(reward))/pi
        f = True
        M = pow(2,bits)
        phase_estimation = [i/M for i in range(M)]
        weight = [0 for x in phase_estimation]
        for i,x in enumerate(phase_estimation):
            Up = (sin(M*self.D(phase,x)*pi))**2
            Down = (M**2)*((sin(self.D(phase,x)*pi))**2)
            if Down==0:
                print(x,self.D(phase,x))
                estimation = reward
                f = False
                break
            else:
                weight[i] = Up/Down
        if f:
            estimation = median([(sin(pi*x))**2 for x in choices(phase_estimation,weights = weight, k=rep)])
        regret = self.best-reward
        return estimation,regret,(M-1)*rep
        
    
    def Lin_UCB(self,delta):
        t = 1
        a = self.actions[0]
        V = np.diag([self.lamb]*self.dimension)+a.T*a
        reward = self.pull_classical_arm(a)
        AX = a.T*reward
        V_inv = np.linalg.inv(V)
        t += 1
        while t<=self.time_horizon:
            if t%10000==0:
                print(t)
            a = self.actions[self.offline_solver_finite(V_inv*AX,V_inv,t,"classical",delta=delta)]
            AX = AX + a.T*self.pull_classical_arm(a)
            V = V + a.T*a
            V_inv = np.linalg.inv(V)
            t += 1
        return True
    
    def Q_Lin_UCB(self,delta,noi=False):
        V = np.diag([self.lamb]*self.dimension)
        rep=5*ceil(log((self.dimension*log((self.time_horizon*self.time_horizon)/(self.dimension*self.lamb)+1))/delta))
        a = self.actions[0]
        a_epsilon = sqrt(a*np.diag([1/self.lamb]*self.dimension)*a.T)
        bits = ceil(log((pi/a_epsilon)*((1+sqrt(1+4*a_epsilon))/2),2))
        
        V = V + pow(4,bits)*a.T*a
        estimation,regret,num_oracle_queries = self.pull_quantum_arm(a, bits, rep)
        
        AWX = a.T*pow(4,bits)*estimation
        X = a
        W_array = [pow(2,bits)]
        t = num_oracle_queries
        new_regret = [self.regret_QLinUCB[-1]+i*regret for i in range(1,num_oracle_queries+1)]
        self.regret_QLinUCB += new_regret
        s = 2
        while t < self.time_horizon:
            V_inv = np.linalg.inv(V)
            theta_hat = V_inv*AWX
            a = self.actions[self.offline_solver_finite(theta_hat,V_inv,s,"quantum",X.T*np.diag(W_array),delta=delta)]
            a_epsilon = sqrt(a*V_inv*a.T)
            bits = ceil(log((pi/a_epsilon)*((1+sqrt(1+4*a_epsilon))/2),2))
            V = V + pow(4,bits)*a.T*a
            X = np.vstack([X,a])  #s*d matrix
            W_array.append(pow(2,bits))
            estimation,regret,num_oracle_queries = self.pull_quantum_arm(a, bits, rep)
            AWX = AWX + a.T*pow(4,bits)*estimation
            if t+num_oracle_queries<self.time_horizon:
                new_regret = [self.regret_QLinUCB[-1]+i*regret for i in range(1,num_oracle_queries+1)]
                self.regret_QLinUCB += new_regret
                t += num_oracle_queries
            else:
                new_regret = [self.regret_QLinUCB[-1]+i*regret for i in range(1,self.time_horizon-t+1)]
                self.regret_QLinUCB += new_regret
                t = self.time_horizon
            s += 1
        return True

dimension = 2
data = []
for i in range(num_repetitions):
    print(i)
    experiment = lin_bandit_experiment(dimension,actions,TH)
    if algo == "LinUCB":
        experiment.Lin_UCB(delta)
        data.append([experiment.regret_LinUCB[i] for i in range(0,TH+1,1000)])
    else:
        experiment.Q_Lin_UCB(delta)
        data.append([experiment.regret_QLinUCB[i] for i in range(0,TH+1,1000)])
    with open(file,'wb') as f:
        pickle.dump(data,f)
