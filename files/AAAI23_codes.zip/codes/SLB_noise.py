from math import acos,sqrt,log,ceil,cos,sin,pi
import numpy as np
from qiskit import QuantumCircuit
from qiskit.algorithms import EstimationProblem
from qiskit import Aer
from qiskit.utils import QuantumInstance
from qiskit.algorithms import AmplitudeEstimation
import qiskit.providers.aer.noise as noise
import pickle

#---------------------------Parameters----------------------------------------
TH = 100000
num_repetition = 100
#depolarizing error rate: (single qubit error, 2-qubit gate error)
error = (0.000333,0.001)
delta = (2*log((TH*TH)/2+1))/TH
#the cumulative regrets list (save the cumulative regret every 1000 rounds) will be saved in file 
file = r'./data/SLB_noise_'+str(error[1])+'_'+str(TH)+'_'+str(delta)+'.txt'
#-----------------------------------------------------------------------------

class lin_bandit_experiment:
    def __init__(self,dimension,num_actions,time_horizon):
        self.dimension = dimension
        self.time_horizon = time_horizon
        self.regret = [0]
        self.theta = np.matrix([cos(0.7*pi/2),sin(0.7*pi/2)])
        self.actions = np.matrix([[cos((i/num_actions)*pi/2),sin((i/num_actions)*pi/2)] for i in range(num_actions)])
        self.reward = [(self.actions[i]*self.theta.T)[0,0] for i in range(len(self.actions))]
        self.best = max(self.reward)
        self.lamb = 1
        
    def get_oracle(self,action):
        oracle = QuantumCircuit(1)
        oracle.u(2*acos(sqrt(1-action*self.theta.T)),0,0,0)
        return oracle
        
    def offline_solver_finite(self,theta_hat,V_inv,stage,mode,XW=None,delta=None):
        if mode == "quantum":
            eig,_ = np.linalg.eig(XW.T*V_inv*XW)
            right = sqrt(stage*max(eig))+sqrt(self.lamb)
        else:
            right = sqrt(2*log(1/delta)-log(pow(self.lamb,self.dimension)*np.linalg.det(V_inv)))+sqrt(self.lamb)
        ucb = [(theta_hat.T*a.T)[0,0] + right*sqrt(a*V_inv*a.T) for a in self.actions]
        return ucb.index(max(ucb))
        
    def mid_of_results(self,result):
        cum = 0
        a = 0
        f = False
        for estimation in sorted(result.samples):
            if f:
                return a+estimation/2
            cum += result.samples[estimation]
            if cum>=0.5:
                if cum==0.5:
                    f = True
                    a = estimation/2
                else:
                    return estimation
    
    
    def Q_Lin_UCB(self,delta,lamb,noi1,noi2):
        regret = [0]
        
        error_1 = noise.depolarizing_error(noi1, 1)
        error_2 = noise.depolarizing_error(noi2, 2)
        
        noise_model = noise.NoiseModel()
        noise_model.add_all_qubit_quantum_error(error_1, ['u1', 'u2', 'u3'])
        noise_model.add_all_qubit_quantum_error(error_2, ['cx'])
            
        basis_gates = ['u1','u2','u3','id','cx']
        
        V = np.diag([lamb]*self.dimension)
        shots=5*ceil(log((self.dimension*log((self.time_horizon*self.time_horizon)/(self.dimension*self.lamb)+1))/delta))
        simulator = QuantumInstance(Aer.get_backend('qasm_simulator'),shots=shots, noise_model=noise_model, basis_gates=basis_gates)
        
        a = self.actions[0]
        a_epsilon = sqrt(a*np.diag([1/lamb]*self.dimension)*a.T)
        bits = ceil(log((pi/a_epsilon)*((1+sqrt(1+4*a_epsilon))/2),2))
        V = V + pow(4,bits)*a.T*a
        oracle = self.get_oracle(a)
        
        AE = AmplitudeEstimation(bits,quantum_instance=simulator)
        problem = EstimationProblem(oracle, 0)
        result = AE.estimate(problem)
        estimation = self.mid_of_results(result)
        
        AWX = a.T*pow(4,bits)*estimation
        X = a
        W_array = [pow(2,bits)]
        t = result.num_oracle_queries
        gap = self.best-(a*self.theta.T)[0,0]
        
        new_regret = [regret[-1]+i*gap for i in range(1,result.num_oracle_queries+1)]
        regret += new_regret
        s = 2
        while t < self.time_horizon:
            print(t)
            V_inv = np.linalg.inv(V)
            theta_hat = V_inv*AWX
            a = self.actions[self.offline_solver_finite(theta_hat,V_inv,s,"quantum",X.T*np.diag(W_array))]
            a_epsilon = sqrt(a*V_inv*a.T)
            bits = ceil(log((pi/a_epsilon)*((1+sqrt(1+4*a_epsilon))/2),2))
            V = V + pow(4,bits)*a.T*a
            X = np.vstack([X,a])  #s*d matrix
            W_array.append(pow(2,bits))
            oracle = self.get_oracle(a)
            AE = AmplitudeEstimation(bits,quantum_instance=simulator)
            problem = EstimationProblem(oracle, 0)
            result = AE.estimate(problem)
            estimation = self.mid_of_results(result)
            AWX = AWX + a.T*pow(4,bits)*estimation
            if t+result.num_oracle_queries<self.time_horizon:
                gap = self.best-(a*self.theta.T)[0,0]
                new_regret = [regret[-1]+i*gap for i in range(1,result.num_oracle_queries+1)]
                regret += new_regret
                t += result.num_oracle_queries
            else:
                gap = self.best-(a*self.theta.T)[0,0]
                new_regret = [regret[-1]+i*gap for i in range(1,self.time_horizon-t+1)]
                regret += new_regret
                t = self.time_horizon
            self.regret = regret
            s += 1
        return True


dimension = 2
actions = 50
data = []

for j in range(num_repetition):
    print(j)
    experiment = lin_bandit_experiment(dimension,actions, TH)
    experiment.Q_Lin_UCB(delta, 1,error[0],error[1])
    data.append([experiment.regret[i] for i in range(0,TH+1,1000)])
    
    with open(file, 'wb') as f:
        pickle.dump(data,f)
        



    
