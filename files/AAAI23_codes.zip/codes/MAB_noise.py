from math import acos,sqrt,log,ceil,pi
from qiskit import QuantumCircuit
from qiskit.algorithms import EstimationProblem
from qiskit import Aer
from qiskit.utils import QuantumInstance
from qiskit.algorithms import AmplitudeEstimation
import qiskit.providers.aer.noise as noise
import pickle

#---------------------------Parameters----------------------------------------
TH = 100000
num_repetition = 100
error = (0.00333,0.001)
delta = 1/TH
#the cumulative regrets list (save the cumulative regret every 1000 rounds) will be saved in file 
file = r'./data/MAB_noise_'+str(error[1])+'_'+str(TH)+'_'+str(delta)+'.txt'
#-----------------------------------------------------------------------------

class MAB_experiment:
    def __init__(self,num_arm):
        self.num_arm = num_arm
        self.regret = [0]
        self.arms_oracle = [0]*num_arm
        
        self.cbandit = [0.5,0.4]
        self.best = max(self.cbandit)
        for i in range(self.num_arm):
            self.arms_oracle[i] = QuantumCircuit(1)
            self.arms_oracle[i].u(2*acos(sqrt(1-self.cbandit[i])),0,0,0)

    def mid_of_results(self,result):
        cum = 0
        a = 0
        f = False
        for estimation in sorted(result.samples):
            if f:
                return a+estimation/2
            cum += result.samples[estimation]
            if cum>=0.5:
                if cum==0.5:
                    f = True
                    a = estimation/2
                else:
                    return estimation
    
    def QMAB(self,delta,time_horizon,noi1,noi2):
        regret = [0]
        error_1 = noise.depolarizing_error(noi1, 1)
        error_2 = noise.depolarizing_error(noi2, 2)

        # Add errors to noise model
        noise_model = noise.NoiseModel()
        noise_model.add_all_qubit_quantum_error(error_1, ['u1', 'u2', 'u3'])
        noise_model.add_all_qubit_quantum_error(error_2, ['cx'])

        # Get basis gates from noise model
        basis_gates = ['u1','u2','u3','cx','id']

        shots=5*ceil(log(1/delta))
        if noi1:
            simulator = QuantumInstance(Aer.get_backend('qasm_simulator'),basis_gates=basis_gates,noise_model=noise_model,shots=shots)
        else:
            simulator = QuantumInstance(Aer.get_backend('qasm_simulator'),shots=shots)
        t = 0
        current_bit = [2 for i in range(self.num_arm)]
        ucb = [10 for i in range(self.num_arm)]
        while t < time_horizon:
            arm_pull = ucb.index(max(ucb))
            AE = AmplitudeEstimation(current_bit[arm_pull],quantum_instance=simulator)
            problem = EstimationProblem(self.arms_oracle[arm_pull],0)
            result = AE.estimate(problem)
            estimation = self.mid_of_results(result)
            num_queries = result.num_oracle_queries
            ucb[arm_pull] = estimation + pi*pow(1/2,current_bit[arm_pull])+pow(pi,2)*pow(1/4,current_bit[arm_pull])
            current_bit[arm_pull] += 1
            if t+num_queries<time_horizon:
                gap = self.best-self.cbandit[arm_pull]
                new_regret = [regret[-1]+i*gap for i in range(1,num_queries+1)]
                regret += new_regret
                t += num_queries
            else:
                gap = self.best-self.cbandit[arm_pull]
                new_regret = [regret[-1]+i*gap for i in range(1,time_horizon-t+1)]
                regret += new_regret
                t = time_horizon
        self.regret = regret
        return True
    

data = []
experiment = MAB_experiment(2)
for i in range(num_repetition):
    print(i)
    
    experiment.QMAB(delta,TH,error[0],error[1])
    data.append([experiment.regret[i] for i in range(0,TH+1,1000)])

    with open(file,'wb') as f:
        pickle.dump(data,f)

