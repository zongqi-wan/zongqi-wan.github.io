*******************************************************
MAB_simulation.py and SLB_simulation.py are used to excute numerical experiments without quantum noise with given algorithm and instance parameters, and they generates regret list data and save them in ./data

******************************************************
MAB_noise.py and SLB_noise.py are used to excute numerical experiments with quantum noise with given algorithm and instance parameters, and they need the qiskit package. They also generates regret list data and save them in ./data

We reserve all the data used to draw the figures in our paper.
******************************************************
draw.py is used to draw the figures in our paper