import pickle
import matplotlib.pyplot as plt
import numpy as np
from math import sqrt
import matplotlib

matplotlib.use("Agg")
matplotlib.rcParams['font.family'] = 'Times New Roman'
matplotlib.rcParams['mathtext.default'] = 'regular'
font_legend = {'family': 'Times New Roman',
               'weight' : 'normal',
               'size' : 20,
               'style' : 'italic',
               'usetex' : True}

"""
#--------------------------------Fig.1 (a)-------------------------------------
files = [r'./data/MAB_UCB_1e-12_0.01_1000000.txt',r'./data/MAB_QUCB_0.005_0.01_1000000.txt',
        r'./data/MAB_QUCB_0.01_0.01_1000000.txt',r'./data/MAB_QUCB_0.03_0.01_1000000.txt',
        './data/MAB_QUCB_1e-06_0.01_1000000.txt']
labels = iter(['UCB','QUCB(0.005)','QUCB(0.01)','QUCB(0.03)','QUCB($1/T$)'])
#--------------------------------Fig.1 (b)-------------------------------------
files = [r'./data/MAB_UCB_1e-12_0.005_1000000.txt',r'./data/MAB_QUCB_0.005_0.005_1000000.txt',
        r'./data/MAB_QUCB_0.01_0.005_1000000.txt',r'./data/MAB_QUCB_0.03_0.005_1000000.txt',
        './data/MAB_QUCB_1e-06_0.005_1000000.txt']
labels = iter(['UCB','QUCB(0.005)','QUCB(0.01)','QUCB(0.03)','QUCB($1/T$)'])

#--------------------------------Fig.1 (c)-------------------------------------
files = [r'./data/MAB_UCB_1e-12_0.002_1000000.txt',r'./data/MAB_QUCB_0.005_0.002_1000000.txt',
        r'./data/MAB_QUCB_0.01_0.002_1000000.txt',r'./data/MAB_QUCB_0.03_0.002_1000000.txt',
        './data/MAB_QUCB_1e-06_0.002_1000000.txt']
labels = iter(['UCB','QUCB(0.005)','QUCB(0.01)','QUCB(0.03)','QUCB($1/T$)'])
#--------------------------------Fig.2 (a)-------------------------------------
files = [r'./data/SLB_LinUCB_1e-06_1000000.txt',r'./data/SLB_QLinUCB_5.387574787074121e-05_1000000.txt',
        r'./data/SLB_QLinUCB_0.005_1000000.txt',r'./data/SLB_QLinUCB_0.01_1000000.txt',
        './data/SLB_QLinUCB_0.03_1000000.txt']
labels = iter(['LinUCB','QLinUCB($m/T$)','QLinUCB(0.005)','QLinUCB(0.01)','QLinUCB(0.03)'])
#--------------------------------Fig.3 (a)-------------------------------------
files = [r'./data/MAB_QUCB_1e-05_0.1_100000.txt',r'./data/MAB_noise_0.001_100000_1e-05.txt',
        r'./data/MAB_noise_0.002_100000_1e-05.txt',r'./data/MAB_noise_0.005_100000_1e-05.txt',
        './data/MAB_noise_0.00683_100000_1e-05.txt',r'./data/MAB_noise_0.01_100000_1e-05.txt']
labels = iter(['QUCB(without noise)','0.000333+0.001','0.000667+0.002','0.00167+0.005','0.00213+0.00683','0.00333+0.01'])

"""
#--------------------------------Fig.3 (b)-------------------------------------
files = [r'./data/SLB_QLinUCB_0.0004466540749916102_100000.txt',r'./data/SLB_noise_0.001_100000_0.0004466540749916102.txt',
         r'./data/SLB_noise_0.002_100000_0.0004466540749916102.txt',r'./data/SLB_noise_0.005_100000_0.0004466540749916102.txt',
         r'./data/SLB_noise_0.00683_100000_0.0004466540749916102.txt',r'./data/SLB_noise_0.01_100000_0.0004466540749916102.txt']
labels = iter(['QLinUCB(without noise)','0.000333+0.001','0.000667+0.002','0.00167+0.005','0.00213+0.00683','0.00333+0.01'])


#------------------------------------------------------------------------------
colors = iter(['red','green','blue','black','cyan','magenta','yellow','olive','saddlebrown'])

def std(a):
    mean = sum(a)/len(a)
    a = list(map(lambda x:(x-mean)**2, a))
    var = sum(a)/(len(a)-1)
    return sqrt(var)

fimg,ax = plt.subplots(1,1)
for file in files:
    with open(file,'rb') as f:
        data = pickle.load(f)
    expectation = []
    regrets = np.array(data).T
    expectation = list(map(lambda x:sum(x)/len(x), regrets))
    data_std = list(map(lambda x:std(x), regrets))
    
    std1 = list(map(lambda x:x[0]+x[1],zip(expectation,data_std)))
    std0 = list(map(lambda x:x[0]-x[1],zip(expectation,data_std)))
    
    color = next(colors)
    ax.plot(list(map(lambda x:1000*x,list(range(len(expectation))))),expectation,label = next(labels),color=color)
    ax.fill_between(list(map(lambda x:1000*x,list(range(len(expectation))))), std1,std0,color = color ,alpha=0.1)
    
ax.set_xlabel('rounds')
ax.set_ylabel('regret')
ax.set_xlim(xmin=0)
ax.set_ylim(ymin=0)
plt.legend()
plt.show()
